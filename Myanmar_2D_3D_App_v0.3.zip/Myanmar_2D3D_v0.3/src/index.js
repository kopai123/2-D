const SETLIVE_BASE = "https://setlive.myanmarnode.com/api/v1";

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff",
      ...extra,
    },
  });
}

async function upstream(path, apiKey) {
  const response = await fetch(`${SETLIVE_BASE}${path}`, {
    method: "GET",
    headers: { "X-API-Key": apiKey, Accept: "application/json" },
  });
  let body;
  try { body = await response.json(); }
  catch { body = { message: "SetLive returned a non-JSON response." }; }
  if (!response.ok || body?.result === 0 || body?.error) {
    const message = body?.message || `SetLive API error (${response.status})`;
    return { ok: false, status: response.ok ? 502 : response.status, error: {
      message,
      code: body?.code || null,
      requestId: response.headers.get("X-Request-Id") || body?.request_id || null,
      retryAfter: response.headers.get("Retry-After") || null,
    } };
  }
  return { ok: true, status: 200, body, creditsRemaining: response.headers.get("X-Credits-Remaining") };
}

async function cachedJson(request, ctx, ttlSeconds, loader) {
  const cache = caches.default;
  const cacheKey = new Request(request.url, { method: "GET" });
  const cached = await cache.match(cacheKey);
  if (cached) {
    const headers = new Headers(cached.headers);
    headers.set("X-App-Cache", "HIT");
    return new Response(cached.body, { status: cached.status, headers });
  }
  const result = await loader();
  if (result.status >= 200 && result.status < 300) {
    const headers = new Headers(result.headers);
    headers.set("Cache-Control", `public, max-age=${ttlSeconds}`);
    headers.set("X-App-Cache", "MISS");
    const cacheable = new Response(result.body, { status: result.status, headers });
    ctx.waitUntil(cache.put(cacheKey, cacheable.clone()));
    return cacheable;
  }
  return result;
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return env.ASSETS.fetch(request);

    if (request.method !== "GET") return json({ ok: false, message: "Method not allowed" }, 405, { Allow: "GET" });
    if (url.pathname === "/api/health") {
      return json({ ok: true, keyConfigured: Boolean(env.SETLIVE_API_KEY), appVersion: "0.3.0" });
    }
    if (!env.SETLIVE_API_KEY) {
      return json({ ok: false, code: "server_key_missing", message: "Server မှာ SetLive API Key မထည့်ရသေးပါ။" }, 503);
    }

    if (url.pathname === "/api/live") {
      return cachedJson(request, ctx, 60, async () => {
        const [two, three] = await Promise.all([
          upstream("/twod-result-live", env.SETLIVE_API_KEY),
          upstream("/threed-result-latest", env.SETLIVE_API_KEY),
        ]);
        if (!two.ok || !three.ok) {
          const failure = !two.ok ? two : three;
          return json({ ok: false, code: failure.error.code, message: failure.error.message,
            requestId: failure.error.requestId, retryAfter: failure.error.retryAfter,
            partial: { twoD: two.ok ? two.body.data : null, threeD: three.ok ? three.body.data : null } }, failure.status);
        }
        const credits = [two.creditsRemaining, three.creditsRemaining].filter(Boolean).map(Number);
        return json({ ok: true, fetchedAt: new Date().toISOString(), twoD: two.body.data || {},
          threeD: three.body.data || {}, schedule: three.body.schedule || null,
          creditsRemaining: credits.length ? Math.min(...credits) : null }, 200,
          { "X-Data-Source": "SetLive", "Cache-Control": "public, max-age=60" });
      });
    }

    if (url.pathname === "/api/history") {
      const type = url.searchParams.get("type") === "3d" ? "3d" : "2d";
      const page = Math.max(1, Math.min(100, Number.parseInt(url.searchParams.get("page") || "1", 10) || 1));
      const perPage = Math.max(1, Math.min(type === "2d" ? 100 : 50, Number.parseInt(url.searchParams.get("per_page") || (type === "2d" ? "20" : "20"), 10) || 20));
      const path = type === "2d"
        ? `/twod-results?per_page=${perPage}&page=${page}`
        : `/threed-results?per_page=${perPage}&page=${page}`;
      const cacheUrl = new URL(request.url);
      cacheUrl.searchParams.set("type", type);
      cacheUrl.searchParams.set("page", String(page));
      cacheUrl.searchParams.set("per_page", String(perPage));
      const cacheRequest = new Request(cacheUrl.toString(), { method: "GET" });
      return cachedJson(cacheRequest, ctx, 600, async () => {
        const result = await upstream(path, env.SETLIVE_API_KEY);
        if (!result.ok) return json({ ok: false, code: result.error.code, message: result.error.message,
          requestId: result.error.requestId, retryAfter: result.error.retryAfter }, result.status);
        return json({ ok: true, type, data: result.body.data || [], meta: result.body.meta || {},
          links: result.body.links || {} }, 200, { "X-Data-Source": "SetLive", "Cache-Control": "public, max-age=600" });
      });
    }
    return json({ ok: false, message: "API route not found" }, 404);
  },
};
