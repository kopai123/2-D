# Myanmar 2D 3D v0.3.0

A mobile-first installable PWA backed by a Cloudflare Worker. The Worker proxies SetLive REST endpoints so the SetLive API key stays server-side as a Worker secret.

## Deploy

1. Create a Cloudflare account and a GitHub repository; upload this project.
2. In Cloudflare Dashboard, create a Worker from the repository. Use the project root and deploy with `npx wrangler deploy`.
3. In Worker Settings → Variables and Secrets, add a **Secret** named `SETLIVE_API_KEY` and paste the key from SetLive.
4. Redeploy. Open the Worker `workers.dev` URL in Android Chrome.
5. In the app, open Settings → Server test. It should report `Server OK · API Key ရှိ`.
6. Tap Update on Home, then Chrome menu → Install app / Add to Home screen.

CLI alternative:

```bash
npm install
npx wrangler login
npx wrangler secret put SETLIVE_API_KEY
npx wrangler deploy
```

## API routes

- `GET /api/health`
- `GET /api/live` — SetLive `/twod-result-live` + `/threed-result-latest`, cached for 60 seconds.
- `GET /api/history?type=2d&page=1&per_page=20`
- `GET /api/history?type=3d&page=1&per_page=20`

## Notes

- No API key is embedded in the PWA or stored in browser localStorage.
- Auto-refresh runs every six hours only while the app is open. Background refresh while closed is not guaranteed by a PWA.
- SetLive 11:00 and 15:00 slots are nearby SET live ticks and can differ from other providers. Check round status before treating them as confirmed.
- Check SetLive's current pricing and plan limits before production use.
