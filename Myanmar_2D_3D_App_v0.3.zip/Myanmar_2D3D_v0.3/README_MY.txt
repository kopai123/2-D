Myanmar 2D 3D — Version 0.3.0

ဒီ ZIP ထဲမှာ Android မှာ Install လုပ်နိုင်မယ့် PWA Website နဲ့ SetLive API ကို လုံခြုံစွာ ချိတ်ဆက်ပေးမယ့် Cloudflare Worker Backend ပါဝင်ပါတယ်။ APK မဟုတ်သေးပါ။ HTTPS URL မှတစ်ဆင့် Chrome ကနေ Install လုပ်ရပါမယ်။

အရေးကြီး — API Key ကို App ထဲ မထည့်ပါနှင့်။ Cloudflare Worker ရဲ့ Secret အဖြစ် Server ဘက်မှာသာ သိမ်းပါ။

ပါဝင်သည့်လုပ်ဆောင်ချက်များ
- SetLive မှ 2D live result နှင့် 3D latest result ရယူခြင်း
- 2D/3D History API ကို လိုအပ်ချိန်တွင် ရယူခြင်း
- 2D 11:00 / 12:01 / 15:00 / 16:30 အချိန်ပိုင်းများ
- ရလဒ်အတည်ပြုအခြေအနေ ပြသခြင်း
- နောက်ဆုံးရလဒ် Local cache, offline shell
- Manual result ထည့်ခြင်း၊ JSON backup ထုတ်ခြင်း
- Android Chrome PWA install
- API Key ကို Server Secret အဖြစ်သာ သိမ်းခြင်း

Deploy လုပ်ရန် (Cloudflare Workers + Static Assets)
1. Cloudflare account တစ်ခု ဖွင့်ပါ။
2. GitHub repository တစ်ခုထဲသို့ ဒီ Project ဖိုင်များ အားလုံး တင်ပါ။ (သို့) Wrangler CLI ဖြင့် Deploy လုပ်နိုင်သည်။
3. Cloudflare Dashboard > Workers & Pages > Create > Import a repository မှ GitHub repo ကို ရွေးပါ။
4. Wrangler project ဖြစ်ကြောင်း သိရှိပြီး deploy လုပ်ပါ။ လိုအပ်ပါက build/deploy command ကို `npx wrangler deploy` ထားပါ။ Root directory ကို project root ထားပါ။
5. Worker Settings > Variables and Secrets > Add > Secret ကိုသွားပါ။ Name ကို `SETLIVE_API_KEY` ထားပြီး SetLive မှ ရယူထားသော API Key ကို Value ထဲ ထည့်ပါ။ Save လုပ်ပြီး Deploy/Retry လုပ်ပါ။
6. Worker URL (ဥပမာ https://myanmar-2d3d-app.<account>.workers.dev) ကို Chrome ဖြင့်ဖွင့်ပါ။
7. App ထဲ Settings > Server စမ်းသပ်မည် ကိုနှိပ်ပါ။ “Server OK · API Key ရှိ” ပြရမည်။ Home > Update ကိုနှိပ်ပြီး ရလဒ်စမ်းပါ။
8. Chrome menu ⋮ > Install app သို့မဟုတ် Add to Home screen ကိုရွေးပါ။

Wrangler CLI ဖြင့် Deploy (ကွန်ပျူတာရှိသူများ)
- `npm install`
- `npx wrangler login`
- `npx wrangler secret put SETLIVE_API_KEY` (prompt ပေါ်လာလျှင် API Key ကို ထည့်ပါ)
- `npx wrangler deploy`

API Endpoint များ
- GET /api/health — Worker နဲ့ Secret ရှိ/မရှိ စစ်ဆေးခြင်း
- GET /api/live — SetLive 2D + 3D latest (Worker cache 60 seconds)
- GET /api/history?type=2d&page=1&per_page=20 — 2D history (cache 10 minutes)
- GET /api/history?type=3d&page=1&per_page=20 — 3D history (cache 10 minutes)

အသုံးပြုမှုနှင့် ကန့်သတ်ချက်
- App ဖွင့်ချိန်တွင် 2 API requests ပြုလုပ်သည်။ Manual Update နှင့် 6 နာရီခြား refresh လုပ်နိုင်သည်။ History ကို History tab ဝင်မှသာ ရယူသည်။
- SetLive Free Plan လက်ရှိဖော်ပြချက်အရ တစ်လ 5,000 API credits နှင့် တစ်မိနစ် 3 requests ဖြစ်သည်။ Plan အသေးစိတ် ပြောင်းလဲနိုင်သောကြောင့် SetLive Pricing ကို ပြန်စစ်ပါ။
- 11:00 နှင့် 15:00 SET reference slots များသည် target time အနီး live tick ကို သုံးနိုင်သောကြောင့် အခြား source နှင့် ကွာနိုင်သည်။ Confirmed/Corrected status ကို စောင့်ကြည့်ပါ။
- PWA သည် App ဖွင့်ထားချိန်တွင်သာ 6 နာရီခြား auto-refresh လုပ်နိုင်သည်။ ဖုန်းက App ကိုပိတ်ထားချိန်မှာ background auto-refresh အာမခံမရှိပါ။
- Internet မရှိပါက နောက်ဆုံးရရှိထားသော cache ကို ပြနိုင်သော်လည်း အသစ်သော result မရနိုင်ပါ။

Security
- SetLive API Key ကို Worker secret `SETLIVE_API_KEY` ထဲမှာသာ ထည့်ပါ။ App localStorage သို့မဟုတ် public source code ထဲ မထည့်ပါနှင့်။
- ဒီ Worker က browser မှာ CORS ပြဿနာ မဖြစ်စေရန် same-origin API proxy အဖြစ် အလုပ်လုပ်သည်။
